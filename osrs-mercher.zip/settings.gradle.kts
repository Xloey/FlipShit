rootProject.name = "osrs-mercher"
include(":app")
