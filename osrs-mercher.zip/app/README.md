
# OSRS Mercher - Starter Android Project (ZIP)
This archive contains a ready-to-build Android Studio project scaffold.

## What it does
- Kotlin + Jetpack Compose UI
- Retrofit + Moshi wiring to the OSRS Wiki prices API
- Room DB for caching items
- A WorkManager CoroutineWorker (ItemsSyncWorker) that, on first run, downloads `items-summary.json` from osrsbox and populates the local DB with item id + name for fast searching.
  - URL: https://www.osrsbox.com/osrsbox-db/items-summary.json
- MPAndroidChart integration for item price charts (skeleton).

## How to build
1. Unzip the archive and open the project in Android Studio (Electric Eel or newer recommended).
2. Let Gradle sync (it will download dependencies).
3. Build APK: `Build -> Build Bundle(s) / APK(s) -> Build APK(s)`.
4. Install on device or emulator.

## Important notes
- The project will download the items summary JSON on first run via WorkManager; the device must have internet.
- The project does not include a prebuilt APK (cannot be built in this environment). Use Android Studio to build.
- For always-on 1-2 minute background monitoring, consider a backend + FCM or implement a foreground service (battery impact).

## Files included
- Gradle configs, manifest, Kotlin source files (network, db, ui, vm), and the ItemsSyncWorker worker.
