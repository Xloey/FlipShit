
package com.example.osrsmercher.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.osrsmercher.db.AppDatabase
import com.example.osrsmercher.model.ItemEntity
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import okhttp3.OkHttpClient
import okhttp3.Request

class ItemsSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    companion object {
        const val ITEMS_SUMMARY_URL = "https://www.osrsbox.com/osrsbox-db/items-summary.json"
    }

    override suspend fun doWork(): Result {
        val client = OkHttpClient()
        val req = Request.Builder().url(ITEMS_SUMMARY_URL).build()
        return try {
            val resp = client.newCall(req).execute()
            if (!resp.isSuccessful) return Result.retry()
            val body = resp.body?.string() ?: return Result.failure()
            // items-summary.json is an array of objects {"id":...,"name":...}
            val moshi = Moshi.Builder().build()
            val type = Types.newParameterizedType(List::class.java, Map::class.java)
            val adapter = moshi.adapter<List<Map<String, Any>>>(type)
            val list = adapter.fromJson(body) ?: emptyList()
            val dao = AppDatabase.get(applicationContext).itemDao()
            val entities = list.mapNotNull { m ->
                val id = (m["id"] as? Double)?.toInt() ?: (m["id"] as? Int)
                val name = m["name"] as? String ?: return@mapNotNull null
                ItemEntity(
                    id = id as Int,
                    name = name,
                    lastPrice = 0L,
                    high = null,
                    low = null,
                    lastUpdated = System.currentTimeMillis()
                )
            }
            if (entities.isNotEmpty()) {
                dao.insertAll(entities)
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
