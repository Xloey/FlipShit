
package com.example.osrsmercher.network

import com.squareup.moshi.Json
import retrofit2.http.GET
import retrofit2.http.Query

data class LatestResponse(
    val data: Map<String, ItemPrice>?
)
data class ItemPrice(
    val id: Int,
    val name: String?,
    val high: Long? = null,
    val low: Long? = null,
    val members: Boolean? = null,
    val trend: String? = null,
    @Json(name = "high") val highPrice: Long? = null,
    @Json(name = "current") val current: Long? = null
)

data class TimeSeriesResponse(
    val data: Map<String, List<List<Long>>>?
)

interface PriceApi {
    @GET("latest")
    suspend fun getLatest(@Query("id") itemId: Int): LatestResponse

    @GET("timeseries")
    suspend fun getTimeSeries(@Query("id") itemId: Int, @Query("period") period: String = "24h"): TimeSeriesResponse

    @GET("latest")
    suspend fun getLatestForMany(@Query("ids") idsCsv: String): LatestResponse
}
