
package com.example.osrsmercher.ui

import android.view.ViewGroup
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet

@Composable
fun PriceChart(pricePoints: List<Pair<Long, Float>>, modifier: Modifier = Modifier) {
    AndroidView(factory = { ctx ->
        LineChart(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 400)
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
        }
    }, modifier = modifier.fillMaxWidth()) { chart ->
        val entries = pricePoints.mapIndexed { index, p -> Entry(index.toFloat(), p.second) }
        val ds = LineDataSet(entries, "Price")
        ds.setDrawCircles(false)
        val data = LineData(ds)
        chart.data = data
        chart.invalidate()
    }
}
