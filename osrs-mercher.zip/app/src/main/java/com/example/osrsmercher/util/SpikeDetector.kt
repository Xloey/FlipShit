
package com.example.osrsmercher.util

fun detectSimpleSpike(recentPrices: List<Long>, pctThreshold: Double = 0.25): Boolean {
    if (recentPrices.size < 5) return false
    val first = recentPrices.first().toDouble()
    val last = recentPrices.last().toDouble()
    val pctChange = (last - first) / (first.coerceAtLeast(1.0))
    return pctChange >= pctThreshold
}
