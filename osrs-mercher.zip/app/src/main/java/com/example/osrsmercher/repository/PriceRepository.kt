
package com.example.osrsmercher.repository

import android.content.Context
import com.example.osrsmercher.db.AppDatabase
import com.example.osrsmercher.di.NetworkModule
import com.example.osrsmercher.model.ItemEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PriceRepository(private val context: Context) {
    private val api = NetworkModule.priceApi
    private val dao = AppDatabase.get(context).itemDao()

    suspend fun refreshItem(itemId: Int) {
        withContext(Dispatchers.IO) {
            try {
                val resp = api.getLatest(itemId)
                val key = itemId.toString()
                val data = resp.data?.get(key)
                if (data != null) {
                    val entity = ItemEntity(
                        id = data.id,
                        name = data.name ?: "Unknown",
                        lastPrice = data.current ?: (data.high ?: 0L),
                        high = data.high ?: data.current,
                        low = data.low,
                        lastUpdated = System.currentTimeMillis()
                    )
                    dao.insert(entity)
                }
            } catch (e: Exception) {
                // log or handle
            }
        }
    }

    suspend fun refreshMany(itemIds: List<Int>) {
        withContext(Dispatchers.IO) {
            try {
                val csv = itemIds.joinToString(",")
                val resp = api.getLatestForMany(csv)
                val entities = resp.data?.values?.mapNotNull { v ->
                    v?.let {
                        ItemEntity(
                            id = it.id,
                            name = it.name ?: "Unknown",
                            lastPrice = it.current ?: (it.high ?: 0L),
                            high = it.high ?: it.current,
                            low = it.low,
                            lastUpdated = System.currentTimeMillis()
                        )
                    }
                } ?: emptyList()
                if (entities.isNotEmpty()) dao.insertAll(entities)
            } catch (e: Exception) {
                // handle
            }
        }
    }

    fun observeItems() = dao.observeAll()

    suspend fun getItem(id: Int) = dao.getById(id)
}
