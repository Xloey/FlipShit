
package com.example.osrsmercher.util

fun parseTimeseries(map: Map<String, List<List<Long>>>?): List<Pair<Long, Float>> {
    if (map == null) return emptyList()
    val key = map.keys.firstOrNull() ?: return emptyList()
    return map[key]?.mapNotNull { row ->
        if (row.size >= 2) Pair(row[0], row[1].toFloat()) else null
    } ?: emptyList()
}
