
package com.example.osrsmercher.ui

import android.content.Context
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.osrsmercher.vm.ItemViewModel
import com.example.osrsmercher.vm.ViewModelFactory
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun AppTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) darkColorScheme() else lightColorScheme(),
        content = content
    )
}

@Composable
fun MainScreen(context: Context) {
    var dark by remember { mutableStateOf(true) }

    AppTheme(darkTheme = dark) {
        Surface(modifier = Modifier.fillMaxSize()) {
            val factory = remember(context) { ViewModelFactory(context) }
            val vm: ItemViewModel = viewModel(factory = factory)

            Scaffold(topBar = {
                TopAppBar(title = { Text("OSRS Mercher") }, actions = {
                    IconButton(onClick = { dark = !dark }) {
                        Icon(imageVector = if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, contentDescription = "Theme")
                    }
                })
            }) { padding ->
                Dashboard(vm = vm, modifier = Modifier.padding(padding))
            }
        }
    }
}
