
package com.example.osrsmercher.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.osrsmercher.repository.PriceRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ItemViewModel(private val repo: PriceRepository) : ViewModel() {
    val items = repo.observeItems().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private var pollingJob: Job? = null

    fun startPollingTop(ids: List<Int>, intervalMs: Long = 2 * 60_000L) {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            while (true) {
                repo.refreshMany(ids)
                delay(intervalMs)
            }
        }
    }

    fun stopPolling() {
        pollingJob?.cancel()
    }

    fun refreshSingle(id: Int) {
        viewModelScope.launch { repo.refreshItem(id) }
    }
}
